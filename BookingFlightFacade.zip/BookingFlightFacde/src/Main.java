public class Main {
    public static void main(String[] args) {
        FlightBookingFacade bookingFacade = new FlightBookingFacade();

        String ticket1 = bookingFacade.bookFlight("Sdu legend", "KZ777", "14B", 320.00, 2, 24.5, "EUR",
                "4532015112830366");
        System.out.println("Result 1: " + ticket1);

        String ticket2 = bookingFacade.bookFlight("Elon Mask", "KZ777", "13A", 320.00, 1, 15.0, "USD",
                "4532015112830366");
        System.out.println("Result 2: " + ticket2);

        String ticket3 = bookingFacade.bookFlight("Donald Trump", "KZ777", "08C", 320.00, 1, 18.0, "KZT",
                "1234");
        System.out.println("Result 3: " + ticket3);
    }
}